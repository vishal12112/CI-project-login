<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-image: url('https://plus.unsplash.com/premium_photo-1701590725721-add548ecdf61?q=80&w=3862&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D');
            background-size: cover;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .login-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            padding: 2rem;
            width: 100%;
            max-width: 600px;
        }
        .captcha-box {
            font-family: monospace;
            font-size: 1.5rem;
            letter-spacing: 2px;
            background:linear-gradient(45deg, #ddd, #ccc);
            padding: 0.5rem;
            border-radius: 5px;
            user-select: none;
        }
        .form-control:focus {
            box-shadow: 0 0 0 0.2rem rgba(99, 102, 241, 0.25);
            border-color: #6366f1;
        }
        .btn-primary {
            background-color: #6366f1;
            border-color: #6366f1;
        }
        .btn-primary:hover {
            background-color: #4f46e5;
            border-color: #4f46e5;
        }
        .input-group-text {
            background-color: transparent;
        }
    </style>

     <script>
   function togglePassword() {
            var passwordField = document.getElementById("password");
            var toggleIcon = document.getElementById("toggleIcon");
            if (passwordField.type === "password") {
                passwordField.type = "text";
                toggleIcon.classList.remove("bi-eye");
                toggleIcon.classList.add("bi-eye-slash");
            } else {
                passwordField.type = "password";
                toggleIcon.classList.remove("bi-eye-slash");
                toggleIcon.classList.add("bi-eye");
            }
        }
    </script>
</head>
<body>
    <div class="container d-flex align-items-center justify-content-center vh-100">
        <div class="login-card w-100">
            <h2 class="text-center mb-4">Welcome To San Softwares</h2>
            <p class="text-center text-muted mb-4">Enter your credentials to access your account</p>
            <form id="loginForm" action="login.php" method="POST">
                <div class="mb-3">
                    <div class="input-group">
                        <span class="input-group-text">
                            <i class="bi bi-envelope"></i>
                        </span>
                        <input type="email" class="form-control" id="email" name="email" placeholder="Email" required>
                    </div>
                </div>
                <div class="mb-3">
                    <div class="input-group">
                        <span class="input-group-text">
                            <i class="bi bi-lock"></i>
                        </span>
                        <input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
                         <button class="btn btn-outline-secondary" type="button" onclick="togglePassword()">
                            <i id="toggleIcon" class="bi bi-eye"></i>

                        </button>
                    </div>
                </div>
                <div class="mb-3">
                    <div class="d-flex align-items-center gap-2 mb-2">
                        <div class="captcha-box flex-grow-1 text-center" id="captchaText"></div>
                        <button type="button" class="btn btn-outline-secondary" onclick="refreshCaptcha()">
                            <i class="bi bi-arrow-clockwise"></i>
                        </button>
                    </div>
                    <input type="text" class="form-control" id="captchaInput" name="captcha" placeholder="Enter captcha" required>
                </div>

                <div class="mb-3 form-check">
                    <input type="checkbox" class="form-check-input" id="rememberMe" name="remember">
                    <label class="form-check-label" for="rememberMe">Remember me</label>
                </div>
                <button type="submit" class="btn btn-primary w-100 mb-3">Sign In</button>
            </form>
        </div>
    </div>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>  
    <script>
        let captchaText = '';
        function generateCaptcha() {
            const chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
            let captcha = '';
            for (let i = 0; i < 6; i++) {
                captcha += chars.charAt(Math.floor(Math.random() * chars.length));
            }
            return captcha;
        }
        function refreshCaptcha() {
            captchaText = generateCaptcha();
            document.getElementById('captchaText').textContent = captchaText;
            document.getElementById('captchaInput').value = '';
        }
        document.getElementById('loginForm').addEventListener('submit', function(e) {
            e.preventDefault();
            const captchaInput = document.getElementById('captchaInput').value; 
            if (captchaInput !== captchaText) {
                alert('Invalid captcha! Please try again.');
                refreshCaptcha();
                return;
            }
            this.submit();
        });
        refreshCaptcha();
    </script>
</body>
</html>