<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>DASHMIN - Bootstrap Admin Template</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">
      <link href="https://th.bing.com/th?id=ODLS.59eeb79e-c53c-465f-965e-21a8d22b2669&w=32&h=32&qlt=90&pcl=fffffc&o=6&pid=1.2" rel="icon">
      <link rel="stylesheet" href="../assets/css/font/bootstrap-icons.min.css">
      <link href="../assets/css/bootstrap.min.css" rel="stylesheet">
      <link href="../assets/css/style.css" rel="stylesheet">
      <style>
           .card {
            background:rgb(243, 246, 249) ;
            backdrop-filter: blur(10px);
            
            padding: 20px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
        }
      </style>
      
</head>

<body>
    <div class="container-xxl position-relative bg-white d-flex p-0">
        
        <?php include_once './navbar.php'; ?>
            <!-- Sale & Revenue Start -->
            
     <nav class="">
  <div class="nav nav-tabs" id="nav-tab" role="tablist">
    <button class="nav-link active" id="nav-home-tab" data-bs-toggle="tab" data-bs-target="#nav-home" type="button" role="tab" aria-controls="nav-home" aria-selected="true">Home</button>
    <button class="nav-link" id="nav-profile-tab" data-bs-toggle="tab" data-bs-target="#nav-profile" type="button" role="tab" aria-controls="nav-profile" aria-selected="false">Profile</button>
  </div>
</nav>
<div class="tab-content" id="nav-tabContent">
  <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab" tabindex="0">Hii user master</div>
  <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab" tabindex="0"><div class="container-xxl position-relative bg-white d-flex p-0 ">
                <div class="user-form card">
                    <form method="POST" id="usermasterForm" enctype="multipart/form-data" name="usermasterForm" class="form card-body">
                        <input type="hidden" name="id" id="userId" value="">
                        <div class="row g-3">
                            <div class="col-12 col-sm-6 col-md-3">
                                <label for="name" class="form-label">Name <span class="text-danger">*</span></label>
                                <input type="text" name="name" id="name" class="form-control form-control-sm" placeholder="Name" value="" minlength="3" maxlength="40" autocomplete="off" required>
                                <div class="text-danger err" id="nameErr"></div>
                            </div>
                            <div class="col-12 col-sm-6 col-md-3">
                                <label for="email" class="form-label">Email <span class="text-danger">*</span></label>
                                <input type="email" name="email" id="email" class="form-control form-control-sm" placeholder="Enter Email" value="" maxlength="24" autocomplete="off" required>
                                <div class="text-danger err" id="emailErr"></div>
                            </div>
                            <div class="col-12 col-sm-6 col-md-3">
                                <label for="phone" class="form-label">Phone Number <span class="text-danger">*</span></label>
                                <input type="text" name="phone" id="phone" maxlength="10" class="form-control form-control-sm" placeholder="Enter Phone Number" value="" autocomplete="off" required>
                                <div class="text-danger err" id="phoneErr"></div>
                            </div>
                            <div class="col-12 col-sm-6 col-md-3">
                                <label for="password" class="form-label">Password <span class="text-danger ">*</span></label>
                                <input type="password" name="password" id="password" class="form-control form-control-sm update-password" maxlength="20" placeholder="Password" value="" autocomplete="off" required>
                                <div class="text-danger err" id="passwordErr"></div>
                            </div>
                            <div class="col-12 col-sm-6 col-md-3 imageDiv" id="imageDiv">
                                <label for="image" class="form-label">Upload Image</label>
                                <input type="file" name="image" id="image" class="form-control form-control-sm image" accept="image/*" placeholder="Upload Image" value="">

                                <span id="loadImg" style="cursor: pointer; display: none; margin-top: 30px;">
                                        <a id="removeImage" name="removeImage" style="cursor: pointer; margin-left: 10px;">
                                            <img src="../assets/icons/delete1.png" alt="Delete" style="width: 20px; height: 20px; border-radius: 50%;">
                                        </a>
                                    <img id="preview" src="" alt="Previous Image" class="img-fluid" style="width: 80px; height: 80px; border-radius: 50%; display: block; margin-top: 5px;">
                                </span>
                            </div>
                            
                            <div class="col-12 col-sm-6 col-md-3" id="statusDiv"><label for="status" class="form-label">Status</label>
                            <select name="status" id="status" class="form-select form-select-sm">
                                    <option value="">Select Status</option>
                                    <option value="1" selected>Active</option>
                                    <option value="0">Inactive</option>
                            </select></div>

                        </div>
                        <div class='d-flex justify-content-end'>
                            <button type="submit" id='usermasterSubmit' class="btn btn-success grp submit "><span class="update-icon"><i class="bi bi-send"></i></span><span class="update-text"> Submit</span></i></button>
                            <button type="reset" class="btn btn-secondary reset grp"><i class="bi bi-x-circle"> Reset</i></button>
                        </div>
                    </form>

                </div>
            </div></div>
 
</div>
            
    </div>
     <script src="../assets/js/js/jquery.js"></script>
    <script src="../assets/js/js/bootstrap.min.js"></script>
    <script src="../assets/js/main.js"></script>
     <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>