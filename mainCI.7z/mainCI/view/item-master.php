<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>DASHMIN - Bootstrap Admin Template</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">
     <link href="https://th.bing.com/th?id=ODLS.59eeb79e-c53c-465f-965e-21a8d22b2669&w=32&h=32&qlt=90&pcl=fffffc&o=6&pid=1.2" rel="icon">
      <link rel="stylesheet" href="../assets/css/font/bootstrap-icons.min.css">
      <link href="../assets/css/bootstrap.min.css" rel="stylesheet">
      <link href="../assets/css/style.css" rel="stylesheet">
      <style>
       
      </style>
      
</head>

<body>
    <div class="container-xxl position-relative bg-white d-flex p-0">
        
        <?php include_once './navbar.php'; ?>
            <!-- Sale & Revenue Start -->
             <nav class="mt-2">
  <div class="nav nav-tabs" id="nav-tab" role="tablist">
    <button class="nav-link active" id="nav-home-tab" data-bs-toggle="tab" data-bs-target="#nav-home" type="button" role="tab" aria-controls="nav-home" aria-selected="true">Home</button>
    <button class="nav-link" id="nav-profile-tab" data-bs-toggle="tab" data-bs-target="#nav-profile" type="button" role="tab" aria-controls="nav-profile" aria-selected="false">Profile</button>
  </div>
</nav>
<div class="tab-content" id="nav-tabContent">
  <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab" tabindex="0">Hii itemmaster</div>
  <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab" tabindex="0"><div class="container-xxl position-relative bg-white d-flex p-0 mt-5">Hii vishal</div></div>
 
</div>
    </div>
     <script src="../assets/js/js/jquery.js"></script>
    <script src="../assets/js/js/bootstrap.min.js"></script>
    <script src="../assets/js/main.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>