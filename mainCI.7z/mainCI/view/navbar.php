<?php $sidebar = ['dashboard' => 'Dashboard,speedometer', 'user-master' => 'User Master,person', 'client-master' => 'Client Master,people','item-master'=>'Item Master,shop', 'invoice-master' => 'Invoice Master,receipt-cutoff'];

$current_page = basename($_SERVER['PHP_SELF'], '.php');
?>
<div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                 <span class="sr-only">Welcome</span>
            </div>
</div>
 <div class="sidebar pe-4 pb-3">
            <nav class="navbar  bg-light navbar-light">
                <!-- <a href="index.html" class="navbar-brand mx-4 mb-3">
                    <h3 class="text-primary"><i class="bi bi-speedometer"></i> WELCOME</h3>
                </a> -->
                <div class="d-flex align-items-center ms-4 mb-4">
                    <div class="position-relative">
                        <img src="https://sansoftwares.com/wp-content/uploads/al_opt_content/IMAGE/sansoftwares.com/wp-content/uploads/2024/06/sansoftwares_newlogo_ajkshdsvash-1.webp.bv_resized_desktop.webp.bv.webp" alt="" style="width: 224px; height: 40px;">      
                    </div>
                </div>
                <div class="navbar-nav w-100">
                    <?php
                       foreach ($sidebar as $key => $value) {
                         $parts = explode(',', $value);
                        $active_class = ($key === $current_page) ? 'active' : '';
                    ?>
                    <a class="nav-item nav-link <?php echo $active_class; ?>" href="./<?php echo $key; ?>.php">
                       <i class="bi bi-<?php echo $parts[1];?>"></i> <?php echo $parts[0]; ?>
                    </a>
            <?php }
            ?>        
                </div>
            </nav>
        </div>
        <div class="content">
            <nav class="navbar navbar-expand bg-light navbar-light sticky-top px-4 py-0">
                <a href="index.html" class="navbar-brand d-flex d-lg-none me-4">
                    <h2 class="text-primary mb-0"><i class="fa fa-hashtag"></i></h2>
                </a>
                <a href="#" class="sidebar-toggler flex-shrink-0">
                    <span class="navbar-toggler-icon"></span>
                </a>     
                <div class="navbar-nav align-items-center ms-auto">   
                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                            <img class="rounded-circle me-lg-2" src="https://plus.unsplash.com/premium_photo-1664474619075-644dd191935f?q=80&w=3869&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="" style="width: 40px; height: 40px;">
                            <span class="d-none d-lg-inline-flex cont">John Doe</span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">
                            <a href="#" class="dropdown-item">My Profile</a>
                            <a href="#" class="dropdown-item">Settings</a>
                            <a href="#" class="dropdown-item">Log Out</a>
                        </div>
                    </div>
                </div>
            </nav>
            <!-- Navbar End -->