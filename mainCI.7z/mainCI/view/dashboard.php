<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>DASHMIN - Bootstrap Admin Template</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">
      <link href="https://th.bing.com/th?id=ODLS.59eeb79e-c53c-465f-965e-21a8d22b2669&w=32&h=32&qlt=90&pcl=fffffc&o=6&pid=1.2" rel="icon">
      <link rel="stylesheet" href="../assets/css/font/bootstrap-icons.min.css">
      <link href="../assets/css/bootstrap.min.css" rel="stylesheet">
      <link href="../assets/css/style.css" rel="stylesheet">
      <style>
       
      </style>
      
</head>

<body>
    <div class="container-xxl position-relative bg-white d-flex p-0">
        
        <?php include_once './navbar.php'; ?>
            <!-- Sale & Revenue Start -->
            <div class="container-fluid pt-4 px-4">
                <div class="row g-4">
                    <div class="col-sm-6 col-xl-3">
                        <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                            <i class="fa fa-chart-line fa-3x text-primary"></i>
                            <div class="ms-3">
                                <p class="mb-2">User</p>
                                <h6 class="mb-0">1234</h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-xl-3">
                        <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                            <i class="fa fa-chart-bar fa-3x text-primary"></i>
                            <div class="ms-3">
                                <p class="mb-2">Clients</p>
                                <h6 class="mb-0">1234</h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-xl-3">
                        <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                            <i class="fa fa-chart-area fa-3x text-primary"></i>
                            <div class="ms-3">
                                <p class="mb-2">Item</p>
                                <h6 class="mb-0">1234</h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-xl-3">
                        <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                            <i class="fa fa-chart-pie fa-3x text-primary"></i>
                            <div class="ms-3">
                                <p class="mb-2">Invoice</p>
                                <h6 class="mb-0">1234</h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </div>
     <script src="../assets/js/js/jquery.js"></script>
    <script src="../assets/js/js/bootstrap.min.js"></script>
    <script src="../assets/js/main.js"></script>
     <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>